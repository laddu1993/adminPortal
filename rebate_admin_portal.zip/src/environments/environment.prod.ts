export const environment = {
    production: true,
    assetUrl: '../assets/', // Update this path based on your actual setup
    name: "(Prod)",
    apiUrl: `https://crmapps.husqvarnagroup.com/rebate_portal/api/rest/v1.0/`
}